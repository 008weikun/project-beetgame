require('./0.6.2/sm.css');
var $ = require('zepto');
$.config = {router: false};
require('./0.6.2/sm.js');