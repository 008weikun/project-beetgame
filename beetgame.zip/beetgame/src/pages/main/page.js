require('./page.less');
require('components/sui/index');
require('components/ui/header/index').render();
require('components/ui/panel/index').render();
require('components/ui/index/index').render();
